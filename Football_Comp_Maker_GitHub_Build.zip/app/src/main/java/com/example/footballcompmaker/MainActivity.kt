package com.example.footballcompmaker

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FootballCompMakerScreen() }
    }
}

@Composable
fun FootballCompMakerScreen() {
    var selectedVideo by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("Henüz maç videosu seçilmedi") }
    var status by remember { mutableStateOf("Video seçerek başlayabilirsin.") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedVideo = uri
            videoName = uri.lastPathSegment ?: "Seçilen video"
            status = "Video seçildi. Analiz servisi henüz bağlanmadı."
        }
    }

    MaterialTheme {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("FOOTBALL", style = MaterialTheme.typography.headlineMedium)
                Text("COMP MAKER", style = MaterialTheme.typography.headlineLarge)
                Text("Maçtan futbolcu futbolcu highlight videoları oluştur.")
                HorizontalDivider()
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("1. Maç videosu", style = MaterialTheme.typography.titleLarge)
                        Text(videoName)
                        Button(
                            onClick = { picker.launch(arrayOf("video/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Maç videosu seç") }
                    }
                }
                Card {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("2. Comp ayarları", style = MaterialTheme.typography.titleLarge)
                        Text("✓ Yakın kamera görüntüleri")
                        Text("✓ Goller için uzak kamera görüntüsü")
                        Text("✓ Her futbolcuya ayrı MP4")
                        Text("Hedef analiz süresi: yaklaşık 30 dakika")
                    }
                }
                Button(
                    onClick = {
                        status = if (selectedVideo == null) {
                            "Önce bir maç videosu seç."
                        } else {
                            "Video seçimi tamam. Otomatik futbolcu tanıma ve video analiz sunucusu henüz kurulmadı."
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Analizi başlat") }
                Text(status, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "Önizleme sürümü: Bu uygulama şu an video seçimini ve arayüzü sağlar. " +
                    "Gerçek futbolcu takibi, yakın çekim tespiti, gol eşleştirme ve MP4 üretimi için " +
                    "ayrı bir yapay zekâ analiz sunucusu gerekir.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}
