# Football Comp Maker — Android başlangıç projesi

Bu ZIP, Android Studio ile açılabilen bir başlangıç projesidir.

## Şu anda çalışan
- Android uygulama arayüzü
- Telefonda video dosyası seçme
- İstenen comp kurallarını gösterme

## Henüz bulunmayan
Bu proje henüz gerçek analiz yapmaz ve APK olarak derlenmiş değildir. Şunlar ayrıca geliştirilmelidir:
- Videoyu güvenli biçimde sunucuya yükleme
- Futbolcu tespiti ve maç boyunca kimlik takibi
- Yayın görüntülerinde yakın plan / geniş plan sınıflandırması
- Gol anlarını bulma ve gollerde geniş kamera görüntüsünü ekleme
- Her futbolcu için MP4 montajı ve indirme

## APK oluşturma
1. Android Studio'yu bilgisayara kur.
2. Bu klasörü Android Studio'da aç.
3. Gradle senkronizasyonunun bitmesini bekle.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. APK, `app/build/outputs/apk/debug/` altında oluşur.

Not: Bu adımlar yalnızca başlangıç uygulamasını derler; yapay zekâ analiz sunucusu bağlanmadan otomatik comp üretmez.
